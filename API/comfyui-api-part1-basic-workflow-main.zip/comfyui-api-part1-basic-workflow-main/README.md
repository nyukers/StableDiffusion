# ComfyUI : API :Part 1 Basic Workflow

These are the files used in my tutorial/guide:<br />
https://medium.com/@yushantripleseven/comfyui-using-the-api-261293aa055a

`basic_workflow_api.py` : The main script.<br />
`workflow_api.json` : API formatted version of the config file.<br /> 
`workflow.json` : regular config file, can be drag/dropped into the ComfyUI.<br />
