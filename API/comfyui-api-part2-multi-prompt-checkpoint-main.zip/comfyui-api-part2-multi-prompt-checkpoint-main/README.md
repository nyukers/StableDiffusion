# ComfyUI : API :Part 2 
# Multi-Prompt, Multi-Checkpoint, Multi-Resolution Workflow

These are the files used in my tutorial/guide: <br />
https://medium.com/@yushantripleseven/comfyui-using-the-api-part-2-daac17fd2727

`multiprompt_multicheckpoint_multires_api_workflow.py` : The main script.<br />
`workflow_api.json` : API formatted version of the config file.<br />
`workflow.json` : regular config file, can be drag/dropped into the ComfyUI.<br />
